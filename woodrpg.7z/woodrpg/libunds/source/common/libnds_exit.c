#include <nds/system.h>

void __libnds_exit(int rc) {
}
